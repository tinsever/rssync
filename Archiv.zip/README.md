# RSSync - RSS Feed Aggregator & Filter

Eine PHP-Applikation zum Verwalten und Filtern von RSS-Feeds. Erstelle eigene Listen, kombiniere verschiedene Quellen und filtere nach Autoren oder Kategorien.

## Features

- **Benutzerkonten**: Registrierung, Login, E-Mail-Verifizierung, Passwort-Reset
- **Kategorien**: Organisiere Quellen nach Ländern oder Themen
- **RSS-Quellen**: Füge beliebige RSS-Feeds hinzu
- **Listen**: Kombiniere mehrere Quellen zu einer gefilterten Liste
- **Filter**: Whitelist/Blacklist für Autoren und Kategorien
- **RSS-Export**: Jede Liste kann als RSS-Feed abonniert werden
- **API**: Endpoints zum Aktualisieren der Feeds via Cron

## Requirements

- PHP 8.2+
- MySQL/MariaDB
- Composer

## Installation

1. **Abhängigkeiten installieren**:
```bash
composer install
```

2. **Umgebungsvariablen konfigurieren**:
```bash
cp env.example .env
# .env anpassen (Datenbankverbindung, etc.)
```

3. **Datenbank erstellen**:
```sql
CREATE DATABASE rssync CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

4. **Migrationen ausführen**:
```bash
composer migrate
```

5. **Standarddaten anlegen** (Länder und Zeitungen):
```bash
composer seed
```

6. **Server starten** (Entwicklung):
```bash
composer start
# oder
php -S localhost:8080 -t public
```

## API Endpoints

### Feeds aktualisieren

Alle Feeds:
```bash
curl http://localhost:8080/api/refresh/all
```

Einzelne Quelle:
```bash
curl http://localhost:8080/api/refresh/{source_id}
```

### Crontab einrichten

```cron
# Alle 30 Minuten Feeds aktualisieren
*/30 * * * * curl -s http://localhost:8080/api/refresh/all > /dev/null
```

## Projektstruktur

```
rssync/
├── config/             # Konfiguration (Container, Routes)
├── database/
│   ├── migrations/     # Phinx Migrationen
│   └── seeds/          # Seeder für Standarddaten
├── public/             # Webroot (index.php)
├── src/
│   ├── Controllers/    # Request Handler
│   ├── Middleware/     # Session, Auth
│   ├── Models/         # Eloquent Models
│   └── Services/       # Business Logic
├── storage/            # Cache, Logs
├── templates/          # Twig Templates
├── composer.json
└── phinx.php           # Migration Config
```

## Technologie-Stack

- **Framework**: Slim 4
- **Templating**: Twig
- **ORM**: Eloquent (Laravel)
- **RSS-Parser**: Laminas Feed
- **Migrationen**: Phinx
- **Frontend**: MaterializeCSS

## Standard-Quellen

Nach dem Seeden sind folgende Quellen verfügbar:

### Deutschland
- Der Spiegel
- Zeit Online
- Süddeutsche Zeitung
- FAZ
- taz
- Heise Online
- Golem

### Österreich
- Der Standard
- Die Presse
- ORF News
- Kurier

### Schweiz
- NZZ
- SRF News
- Tages-Anzeiger

### International
- Reuters
- BBC News
- The Guardian
- Al Jazeera

### Allgemein
- Hacker News
- Ars Technica

## Lizenz

MIT

